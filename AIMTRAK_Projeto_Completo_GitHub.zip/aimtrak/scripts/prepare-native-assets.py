"""Convert Rocklan's publicly shared models and native PSA clips to self-contained glTF.
Run with Blender --background --disable-autoexec --python this.py -- INPUT ADDON OUTPUT.
Use DarklightGames io_scene_psk_psa 7.1.0 (GPL-3.0) as an installed build dependency.
The model pack stores legacy bone-axis metadata: preserve it when importing PSA.
"""
import bpy,sys,json,re
from pathlib import Path
from mathutils import Quaternion,Vector
args=sys.argv[sys.argv.index('--')+1:];source,addon,dest=map(Path,args);dest.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(addon))
from io_scene_psk_psa.psa.reader import PsaReader
from io_scene_psk_psa.psa.importer import import_psa,PsaImportOptions
import io_scene_psk_psa.psa.importer as importer
calculate=importer._calculate_fcurve_data
def legacy_axes(b,key):
 data=b.armature_bone
 if 'orig_quat' in data:
  b.original_rotation=Quaternion(data['orig_quat']);b.original_location=Vector(data['orig_loc']);b.post_rotation=Quaternion(data['post_quat'])
 return calculate(b,key)
importer._calculate_fcurve_data=legacy_axes
class MeterReader(PsaReader):
 def read_sequence_data_matrix(self,name):
  data=super().read_sequence_data_matrix(name);data[:,:,4:7]*=.01;return data
specs={
 'hands':('jettFirstPerson.blend',{'Idle':'FP_Core_AK_S0_IdlePose','Equip':'FP_Core_AK_S0_Equip','Fire':'FP_Core_AK_S0_Fire','Reload':'FP_Core_AK_S0_Reload','Inspect':'FP_Core_AK_S0_Inspect'}),
 'body':('jettSimple.blend',{'Idle':'TP_Core_AK_S0_IdlePose','UpperIdle':'TP_Core_AK_S0_IdlePose_UB','LowerIdle':'TP_Core_Idle_LB','WalkE':'TP_Core_WalkE_LB','WalkW':'TP_Core_WalkW_LB'}),
 'vandal':('Vandal.blend',{'Equip':'GN_Core_AK_S0_Equip','Fire':'GN_Core_AK_S0_Fire','Reload':'GN_Core_AK_S0_Reload'})
}
report={}
for kind,(blend,clips) in specs.items():
 bpy.ops.wm.open_mainfile(filepath=str(source/blend),use_scripts=False)
 rig=next(o for o in bpy.data.objects if o.type=='ARMATURE');rig.name={'hands':'JettHandsRig','body':'JettBodyRig','vandal':'VandalRig'}[kind]
 for obj in list(bpy.data.objects):
  if obj.type not in {'MESH','ARMATURE'}:bpy.data.objects.remove(obj,do_unlink=True)
  else:obj.hide_set(False);obj.hide_viewport=False;obj.hide_render=False;obj.animation_data_clear()
 for bone in rig.pose.bones:
  for c in list(bone.constraints):bone.constraints.remove(c)
  bone.matrix_basis.identity();bone.rotation_mode='QUATERNION'
 for a in list(bpy.data.actions):bpy.data.actions.remove(a)
 if kind=='vandal':
  mag=next(o for o in bpy.data.objects if o.type=='MESH' and 'Magazine' in o.name);group=mag.vertex_groups.new(name='Magazine_Main');group.add(list(range(len(mag.data.vertices))),1,'REPLACE');mod=mag.modifiers.new('NativeMagazine','ARMATURE');mod.object=rig;mag.parent=rig
 for mat in bpy.data.materials:
  if not mat.use_nodes:continue
  images=[n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE' and n.image]
  diffuse=next((im for im in images if '_DF.' in im.name),None)
  normal=next((im for im in images if '_NM.' in im.name),None)
  if not diffuse:continue
  mat.node_tree.nodes.clear();nodes=mat.node_tree.nodes;links=mat.node_tree.links
  output=nodes.new('ShaderNodeOutputMaterial');bsdf=nodes.new('ShaderNodeBsdfPrincipled');tex=nodes.new('ShaderNodeTexImage');tex.image=diffuse
  bsdf.inputs['Roughness'].default_value=.62 if kind=='vandal' else .78;bsdf.inputs['Metallic'].default_value=.3 if kind=='vandal' else 0
  links.new(tex.outputs['Color'],bsdf.inputs['Base Color']);links.new(bsdf.outputs['BSDF'],output.inputs['Surface'])
  if normal:
   normtex=nodes.new('ShaderNodeTexImage');normtex.image=normal;normal.colorspace_settings.name='Non-Color';norm=nodes.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.65;links.new(normtex.outputs['Color'],norm.inputs['Color']);links.new(norm.outputs['Normal'],bsdf.inputs['Normal'])
  for image in [diffuse,normal]:
   if not image:continue
   if image.size[0]>1024:image.scale(1024,1024)
   image.file_format='PNG';image.pack()
 durations={}
 for name,filename in clips.items():
  reader=MeterReader(str(source/(filename+'.psa')));opts=PsaImportOptions();opts.sequence_names=list(reader.sequences);opts.should_write_metadata=False;opts.should_use_fake_user=True;opts.fps_source='CUSTOM';opts.fps_custom=30
  previous=set(bpy.data.actions);res=import_psa(bpy.context,reader,rig,opts);action=next(a for a in bpy.data.actions if a not in previous);action.name=name
  durations[name]={'frames':next(iter(reader.sequences.values())).frame_count,'sourceFps':next(iter(reader.sequences.values())).fps,'bakedFrames':list(action.frame_range)}
  # Lower-body layers retain only actual lower-body tracks; upper body keeps rifle grip.
  if kind=='body' and name in {'LowerIdle','WalkE','WalkW'}:
   allowed={'Root','Splitter','Pelvis','IK_RootTarget','L_IK_FootTarget','R_IK_FootTarget'}
   allowed.update(b.name for b in rig.data.bones if any(p.name=='Pelvis' for p in b.parent_recursive))
   for curve in list(action.fcurves):
    m=re.search(r'pose.bones\["([^"]+)"\]',curve.data_path)
    if m and m.group(1) not in allowed:action.fcurves.remove(curve)
  if kind=='body' and name=='UpperIdle':
   excluded={'Root','Splitter','Pelvis','IK_RootTarget','L_IK_FootTarget','R_IK_FootTarget'}
   excluded.update(b.name for b in rig.data.bones if any(p.name=='Pelvis' for p in b.parent_recursive))
   for curve in list(action.fcurves):
    m=re.search(r'pose.bones\["([^"]+)"\]',curve.data_path)
    if m and m.group(1) in excluded:action.fcurves.remove(curve)
  reader.fp.close()
 bpy.context.scene.render.fps=30;bpy.context.scene.frame_start=0;bpy.context.scene.frame_end=180
 rig.animation_data_create();rig.animation_data.action=None
 # A separate NLA track per action gives portable names and isolated exports.
 for name in clips:
  action=bpy.data.actions[name];track=rig.animation_data.nla_tracks.new();track.name=name;strip=track.strips.new(name,0,action);track.mute=True
 bpy.context.scene.frame_set(0);bpy.context.view_layer.update()
 bpy.ops.object.select_all(action='SELECT');bpy.context.view_layer.objects.active=rig
 bpy.ops.export_scene.gltf(filepath=str(dest/(kind+'.glb')),export_format='GLB',use_selection=True,export_yup=True,export_image_format='JPEG',export_jpeg_quality=91,export_animations=True,export_animation_mode='NLA_TRACKS',export_force_sampling=True,export_skins=True,export_all_influences=False,export_nla_strips=True,export_anim_single_armature=True,export_optimize_animation_size=True)
 report[kind]={'clips':durations,'bones':len(rig.data.bones),'vertices':sum(len(o.data.vertices) for o in bpy.data.objects if o.type=='MESH')}
 print('EXPORTED',kind,json.dumps(report[kind]),flush=True)
(dest/'native-manifest.json').write_text(json.dumps(report,indent=2))
