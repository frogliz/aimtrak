import fs from 'node:fs/promises';
import path from 'node:path';
const source=process.argv[2];if(!source)throw new Error('Pass the directory containing hands/body/vandal.glb');
let js='// Native meshes and clips; provenance in licenses/native-assets.txt.\n';
for(const name of ['vandal','hands','body']){const bytes=await fs.readFile(path.join(source,`${name}.glb`));js+=`export const ${name.toUpperCase()}=${JSON.stringify(bytes.toString('base64'))};\n`;}
await fs.writeFile('dist/assets/native-data.js',js);
