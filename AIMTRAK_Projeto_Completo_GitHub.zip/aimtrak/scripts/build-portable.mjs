import fs from 'node:fs/promises';
import path from 'node:path';
import {build} from 'esbuild';

const project=process.cwd(),dist=path.join(project,'dist');
const output=process.argv[2];if(!output)throw new Error('Pass the absolute output HTML path.');
const bundled=await build({entryPoints:[path.join(dist,'app.js')],bundle:true,write:false,format:'iife',minify:true,target:['chrome110','firefox115','safari16'],legalComments:'inline'});
const safeScript=text=>text.replace(/<\/script/gi,'<\\/script');
let html=await fs.readFile(path.join(dist,'index.html'),'utf8');
let css=await fs.readFile(path.join(dist,'style.css'),'utf8');
const fontRefs=[...css.matchAll(/url\('\.\/([^']+)'\)/g)];
for(const match of fontRefs){const bytes=await fs.readFile(path.join(dist,match[1]));css=css.replaceAll(match[0],`url('data:font/ttf;base64,${bytes.toString('base64')}')`);}
html=html.replace(/<script type="importmap">[\s\S]*?<\/script>/,'');
html=html.replace('<link rel="stylesheet" href="./style.css">',()=>`<style>${css}</style>`);
const favicon=await fs.readFile(path.join(dist,'favicon.svg'));
html=html.replace('./favicon.svg',()=>`data:image/svg+xml;base64,${favicon.toString('base64')}`);
const icons=await fs.readFile(path.join(dist,'vendor/lucide.min.js'),'utf8');
html=html.replace('<script src="./vendor/lucide.min.js"></script>',()=>`<script>${safeScript(icons)}</script>`);
html=html.replace('<script type="module" src="./app.js"></script>',()=>`<script>${safeScript(bundled.outputFiles[0].text)}</script>`);
html=html.replace('<title>AIMTRAK — Sua próxima evolução.</title>','<title>AIMTRAK — Versão portátil</title>');
let notices='';for(const file of await fs.readdir(path.join(dist,'licenses'))){notices+=`\n\n${file}\n${await fs.readFile(path.join(dist,'licenses',file),'utf8')}`;}
html=html.replace('</body>',()=>`<!-- Redistribution notices${notices.replaceAll('-->','—>')}\n-->\n</body>`);
await fs.mkdir(path.dirname(output),{recursive:true});await fs.writeFile(output,html);
if(/(?:src|href)="\.\//.test(html))throw new Error('Portable HTML still references an external runtime file.');
console.log(JSON.stringify({output,bytes:Buffer.byteLength(html),networkRequired:false}));
