import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const root=path.join(project,'dist');
const host=process.env.AIMTRAK_HOST||'127.0.0.1';
const port=Number(process.env.AIMTRAK_PORT||4173);
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('AIMTRAK_PORT precisa estar entre 1 e 65535.');
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8','.ttf':'font/ttf','.png':'image/png','.jpg':'image/jpeg','.glb':'model/gltf-binary','.mp3':'audio/mpeg'};

const server=http.createServer(async(req,res)=>{
  if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,{'Allow':'GET, HEAD'});res.end();return;}
  try{
    const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);
    const file=path.resolve(root,'.'+(pathname==='/'?'/index.html':pathname));
    if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
    const stat=await fsp.stat(file);
    if(!stat.isFile()){res.writeHead(404);res.end('Not found');return;}
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':stat.size,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});
    if(req.method==='HEAD'){res.end();return;}
    const stream=fs.createReadStream(file);
    stream.on('error',()=>res.destroy());
    res.on('close',()=>stream.destroy());
    stream.pipe(res);
  }catch(error){
    const status=error instanceof URIError?400:error.code==='ENOENT'||error.code==='ENOTDIR'?404:500;
    if(!res.headersSent)res.writeHead(status);
    res.end(status===404?'Not found':status===400?'Bad request':'Server error');
  }
});
server.on('error',error=>{console.error(error.code==='EADDRINUSE'?`A porta ${port} já está em uso. Defina AIMTRAK_PORT para escolher outra.`:error.message);process.exitCode=1;});
server.listen(port,host,()=>console.log(`AIMTRAK pronto em http://${host==='127.0.0.1'?'localhost':host}:${port}`));
for(const signal of ['SIGINT','SIGTERM'])process.once(signal,()=>server.close(()=>process.exit()));
