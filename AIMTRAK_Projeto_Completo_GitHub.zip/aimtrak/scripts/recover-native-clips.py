#!/usr/bin/env python3
"""Recover the previously verified public Rocklan clips, without authentication.

Default: 13 clips required for AIMTRAK integration. --all: all 23 previous clips.
Existing files are retained only after checking their expected size and PSA header.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import struct
import urllib.request

PACK_URL = "https://drive.google.com/drive/folders/17pJMWTGJloEFU86NE9sIOBlH4VB9rFVh"
CREATOR_URL = "https://www.youtube.com/watch?v=we_cLH2S188"
CLIPS = [
    ("FP_Core_AK_S0_Equip.psa", "1P54ggzk4SDxpTWpRIhKqsJecdYLNIhdk", 512008),
    ("FP_Core_AK_S0_Fire.psa", "13FtGlqB93LlqSAx9byNB8b9l7gZY7vL_", 112648),
    ("FP_Core_AK_S0_IdlePose.psa", "1ReGq5NphoOvNSLoLWwgxzg_2R1Nqx12S", 22792),
    ("FP_Core_AK_S0_Inspect.psa", "1YFivBI-pX9Ufvwzs33jZLki4dFdMTZp4", 1265800),
    ("FP_Core_AK_S0_Inspect_Loop.psa", "1C42qCRz4kj0H-tWs8YjcuRtsundh9V_t", 1021192),
    ("FP_Core_AK_S0_Inspect_Loop_Intro.psa", "1-0_wD-WMET3shQacgW1pxEV6AtcmoV9e", 332296),
    ("FP_Core_AK_S0_Reload.psa", "1eJTz8-iMh2XRxofc9918kMHJa1l42Nqf", 896392),
    ("FP_Core_AK_S0_RunAdd.psa", "1IZhjuzBY1kpzQ7YAMxqe2vhLXW6Uz8PB", 107656),
    ("FP_Core_AK_S0_WalkAdd.psa", "1-goK5Kx0G2RnVlkwKknisxWwJjnx1qi4", 152584),
    ("GN_Core_AK_S0_Equip.psa", "1VjnwFzwvgAGqpDwBSX2tyrsSL36JC9Q5", 162688),
    ("GN_Core_AK_S0_Fire.psa", "1LqDzMHNDJt4eUq5ZTbG7dSO2tOQmBjQ8", 35968),
    ("GN_Core_AK_S0_Reload.psa", "1creg2BMcMUmfI1-LV-az994LPEdqqWAC", 284656),
    ("TP_Core_AK_S0_IdlePose.psa", "1FRcbEPMtg2NR1V1tegkeMYjOgfK1_Wrs", 191680),
    ("TP_Core_AK_S0_IdlePose_UB.psa", "1I86zLoz40vx5_HR2cVTEnvYJ59cZFOwN", 31744),
    ("TP_Core_Idle_LB.psa", "150PKW5iw89HJNHzpFx1i4hHzVd5ICVkt", 797152),
    ("TP_Core_RunE_LB.psa", "1sl4fFdOp8baQM3QoOBtw9rIJTW_bo3lc", 225952),
    ("TP_Core_RunW_LB.psa", "1EaWY-9MBE79e0NqhqzF-MrcaSSlds84e", 225952),
    ("TP_Core_WalkAddE_UB.psa", "1SzPU9NBNTqbhalH5fvCviN42OUcnFGYB", 168832),
    ("TP_Core_WalkAddW_UB.psa", "1JjrTwfNIPH6FGNd29ozdnJDqpNr4mTXy", 168832),
    ("TP_Core_WalkE_LB.psa", "1Ak77-E0nxT7PA4it7Os_G1V9OxnNpUKU", 168832),
    ("TP_Core_WalkN_LB.psa", "16ARQXQxVzA0oRk3FxL6HHp7Ic3y8oNvI", 168832),
    ("TP_Core_WalkS_LB.psa", "1XZ6PDm4W6mAq0FqG580q7FBcqcxZzCAT", 168832),
    ("TP_Core_WalkW_LB.psa", "1atF929wjFN_SDCBq_gpcFrZVNwwdMyR2", 168832),
]
OPTIONAL = {
    "FP_Core_AK_S0_Inspect_Loop.psa",
    "FP_Core_AK_S0_Inspect_Loop_Intro.psa",
    "FP_Core_AK_S0_RunAdd.psa",
    "FP_Core_AK_S0_WalkAdd.psa",
    "TP_Core_RunE_LB.psa", "TP_Core_RunW_LB.psa",
    "TP_Core_WalkAddE_UB.psa", "TP_Core_WalkAddW_UB.psa",
    "TP_Core_WalkN_LB.psa", "TP_Core_WalkS_LB.psa",
}


def parse_psa(data: bytes) -> dict:
    if not data.startswith(b"ANIMHEAD"):
        raise ValueError("Not an ActorX PSA animation file")
    pos = 0
    result = {"animations": []}
    while pos + 32 <= len(data):
        name, flags, size, count = struct.unpack_from("<20s3i", data, pos)
        name = name.split(b"\0", 1)[0].decode("ascii", errors="replace")
        pos += 32
        if size < 0 or count < 0 or pos + size * count > len(data):
            raise ValueError(f"Invalid {name} chunk at {pos}")
        if name == "BONENAMES":
            result["bones"] = count
        if name == "ANIMINFO":
            for index in range(count):
                off = pos + index * size
                result["animations"].append({
                    "name": data[off:off+64].split(b"\0", 1)[0].decode(),
                    "bones": struct.unpack_from("<i", data, off + 128)[0],
                    "fps": struct.unpack_from("<f", data, off + 152)[0],
                    "frames": struct.unpack_from("<i", data, off + 164)[0],
                })
        pos += size * count
    if not result["animations"]:
        raise ValueError("PSA contains no animation sequences")
    return result


def recover(item: tuple, out: Path) -> dict:
    name, file_id, expected_bytes = item
    destination = out / name
    data = destination.read_bytes() if destination.exists() else b""
    valid_cached = len(data) == expected_bytes and data.startswith(b"ANIMHEAD")
    if not valid_cached:
        url = "https://drive.google.com/uc?export=download&id=" + file_id
        with urllib.request.urlopen(url, timeout=40) as response:
            if "text/html" in response.headers.get("Content-Type", ""):
                raise ValueError(f"{name}: download returned an HTML page; stopped")
            data = response.read()
        if len(data) != expected_bytes:
            raise ValueError(f"{name}: expected {expected_bytes} bytes, got {len(data)}")
        metadata = parse_psa(data)
        temporary = destination.with_suffix(".psa.part")
        temporary.write_bytes(data)
        temporary.replace(destination)
    else:
        metadata = parse_psa(data)
    return {
        "name": name, "path": str(destination), "file_id": file_id,
        "source_url": "https://drive.google.com/file/d/" + file_id + "/view",
        "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        **metadata,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    selected = [item for item in CLIPS if args.all or item[0] not in OPTIONAL]
    files, errors = [], []
    with ThreadPoolExecutor(max_workers=6) as pool:
        jobs = {pool.submit(recover, item, args.output): item[0] for item in selected}
        for future in as_completed(jobs):
            name = jobs[future]
            try:
                result = future.result()
                files.append(result)
                print("READY", result["name"], result["bytes"], flush=True)
            except Exception as error:
                errors.append({"name": name, "error": str(error)})
                print("ERROR", name, str(error), flush=True)
    manifest = {
        "creator": "Rocklan", "creator_source": CREATOR_URL,
        "pack_folder": PACK_URL,
        "distribution": "Creator publishes the pack as a free download. Game assets remain Riot Games property. No separate CC license found for the Rocklan pack.",
        "all_previously_verified_clip_ids": [
            {"name": name, "file_id": file_id, "expected_bytes": size}
            for name, file_id, size in CLIPS
        ],
        "files": sorted(files, key=lambda item: item["name"]), "errors": errors,
    }
    manifest_path = args.output / "recovered-clips-manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print("MANIFEST", manifest_path, "FILES", len(files), "ERRORS", len(errors), flush=True)
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
