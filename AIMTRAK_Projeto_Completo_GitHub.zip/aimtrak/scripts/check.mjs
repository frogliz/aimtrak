import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
async function modules(dir){
  const files=[];
  for(const item of await fs.readdir(dir,{withFileTypes:true})){
    const file=path.join(dir,item.name);
    if(item.isDirectory())files.push(...await modules(file));
    else if(/\.(?:js|mjs)$/.test(item.name))files.push(file);
  }
  return files;
}
const files=[...await modules(path.join(root,'dist')),...await modules(path.join(root,'scripts'))];
for(const file of files){
  const result=spawnSync(process.execPath,['--check',file],{encoding:'utf8'});
  if(result.status!==0){process.stderr.write(result.stderr||result.error?.message||'Syntax check failed');process.exit(1);}
}
for(const file of ['dist/index.html','dist/style.css','dist/vendor/three.module.js','dist/assets/native-data.js','dist/assets/gaia-audio-data.js','dist/licenses/NOTICE.txt'])await fs.access(path.join(root,file));
console.log(`Sintaxe válida em ${files.length} módulos; arquivos essenciais presentes.`);
