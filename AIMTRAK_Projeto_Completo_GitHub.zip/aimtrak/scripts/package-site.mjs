import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const output=path.join(root,'build');
await fs.rm(output,{recursive:true,force:true});
await fs.cp(path.join(root,'dist'),output,{recursive:true});
await fs.copyFile(path.join(root,'AIMTRAK.html'),path.join(output,'AIMTRAK.html'));
await fs.writeFile(path.join(output,'.nojekyll'),'');
console.log('Distribuição pronta em build/ (jogo modular + AIMTRAK.html).');
