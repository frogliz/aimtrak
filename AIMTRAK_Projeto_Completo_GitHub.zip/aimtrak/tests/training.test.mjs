import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {sensitivityMetrics,mouseRotation,verticalFov,validateSettings,accuracy,ammoAfterShot,DEFAULT_SETTINGS,WEAPONS} from '../dist/core.js';
import {CompatibilityRenderer} from '../dist/compat-renderer.js';
import {AimRange} from '../dist/engine.js';
import {cloneNativeAsset} from '../dist/native-assets.js';
import {KillSequence} from '../dist/kill-sequence.js';
import {BurstGate,DRILL_RULES} from '../dist/training-rules.js';
import {RecoilController} from '../dist/recoil.js';
import {RangeAudio} from '../dist/audio.js';
import {createJett} from '../dist/character-assets.js';
import {FirstPersonRig} from '../dist/viewmodel.js';
const near=(a,b,epsilon=1e-8)=>assert.ok(Math.abs(a-b)<epsilon,`${a} != ${b}`);

test('the default 0.175 / 1600 DPI preserves angular scale and physical distance',()=>{
  near(DEFAULT_SETTINGS.sens,.175);const s=sensitivityMetrics(1600,.175);near(s.edpi,280);near(s.cm360,46.6530612244898);near(mouseRotation(360/(.175*.07),.175),2*Math.PI);
});
test('DPI changes physical distance; it never multiplies camera rotation again',()=>{
  const a=sensitivityMetrics(800,.33),b=sensitivityMetrics(1600,.165);near(a.cm360,b.cm360);near(mouseRotation(100,.165),.020158552860534506);
});
test('calibration factor follows measured trainer-distance divided by game-distance',()=>{
  near(sensitivityMetrics(1600,.165,1.1).cm360*1.1,sensitivityMetrics(1600,.165).cm360);
});
test('103-degree horizontal projection remains exact at 16:9',()=>{
  const vf=verticalFov(103);near(2*Math.atan(Math.tan(vf*Math.PI/360)*(16/9))*180/Math.PI,103);
});
test('Portuguese decimal input and invalid values are handled',()=>{
  near(validateSettings({...DEFAULT_SETTINGS,sens:'0,165'}).sens,.165);assert.throws(()=>validateSettings({...DEFAULT_SETTINGS,dpi:0}));assert.throws(()=>validateSettings({...DEFAULT_SETTINGS,sens:'abc'}));assert.equal(validateSettings({...DEFAULT_SETTINGS,name:'<test>'}).name,'<test>');
});
test('shot counters handle no shots and finite / infinite ammunition',()=>{
  near(accuracy(0,0),0);near(accuracy(3,4),75);assert.equal(ammoAfterShot(1,false),0);assert.equal(ammoAfterShot(0,false),0);assert.equal(ammoAfterShot(25,true),25);
});
test('animated bot has a separate head hitbox and opaque cover blocks it',()=>{
  const engine=Object.create(AimRange.prototype);engine.p={accent:0xdf7d51};engine.scene=new THREE.Scene();engine.colliders=[];engine.occluders=[];const target=engine.bot();target.root.position.set(0,0,-10);engine.scene.updateMatrixWorld(true);const ray=new THREE.Raycaster(new THREE.Vector3(0,1.69,0),new THREE.Vector3(0,0,-1));const hit=ray.intersectObjects(target.hitMeshes,false)[0];assert.equal(hit.object.userData.part,'head');
  const cover=engine.box(2,3,1,0,1.5,-5,0x333333,engine.scene,true);engine.scene.updateMatrixWorld(true);const blocked=ray.intersectObjects([...target.hitMeshes,cover],false)[0];assert.equal(blocked.object,cover);assert.equal(engine.blocked(new THREE.Vector3(0,1.65,-5)),true);assert.equal(engine.blocked(new THREE.Vector3(4,1.65,-5)),false);
});
test('compatibility renderer draws real geometry with emissive materials and near clipping',()=>{
  let fills=0;const ctx={fillRect(){},beginPath(){},moveTo(){},lineTo(){},closePath(){},fill(){fills++;},stroke(){},save(){},restore(){},clip(){},transform(){},drawImage(){}};globalThis.document={createElement:()=>({getContext:()=>ctx})};const renderer=new CompatibilityRenderer();renderer.setSize(640,360);const scene=new THREE.Scene();scene.background=new THREE.Color(0xaabbcc);const camera=new THREE.PerspectiveCamera(60,16/9,.025,100);const mesh=new THREE.Mesh(new THREE.BoxGeometry(2,2,2),new THREE.MeshStandardMaterial({color:0x77aabb,emissive:0x111111}));mesh.position.z=-5;scene.add(mesh);renderer.render(scene,camera);assert.ok(fills>0);fills=0;mesh.position.set(0,-1,-.5);mesh.scale.set(40,1,40);renderer.render(scene,camera);assert.ok(fills>0,'near-plane-intersecting geometry must remain visible');delete globalThis.document;
});

test('live firing registers headshots, enforces head-only, respects cover and consumes ammunition',()=>{
  const e=Object.create(AimRange.prototype);Object.assign(e,{p:{accent:0xdf7d51},scene:new THREE.Scene(),colliders:[],occluders:[],running:true,locked:true,countdown:0,ended:false,reloadTime:0,mode:'micro',weapon:WEAPONS.vandal,weaponKey:'vandal',elapsed:1,shotTime:-10,options:{infinite:false,headOnly:true},ammo:25,settings:{...DEFAULT_SETTINGS,recoil:false},stats:{shots:0,hits:0,headshots:0,kills:0,headKills:0,killIntervals:[],shotPoints:[]},lastKill:0,lastKillAt:-10,streak:0,recoil:0,speed:0,jumpY:0,ray:new THREE.Raycaster(),flash:new THREE.Object3D(),flashLight:{intensity:0},audio:{shot(){},hit(){},kill(){}},tracer(){},impact(){}});e.camera=new THREE.PerspectiveCamera(verticalFov(103),16/9,.025,100);e.camera.position.set(0,1.69,0);e.scene.add(e.camera);const t=e.bot();t.root.position.set(0,0,-10);e.targets=[t];e.fire();assert.equal(e.stats.kills,1);assert.equal(e.stats.headshots,1);assert.equal(e.ammo,24);e.elapsed=1.02;e.fire();assert.equal(e.stats.shots,1,'fire cadence must be enforced');
  t.alive=true;t.root.visible=true;t.health=100;e.camera.position.y=1.2;e.elapsed=1.3;e.fire();assert.equal(t.health,100,'body damage must be disabled in head-only mode');assert.equal(e.stats.hits,2);assert.equal(e.stats.kills,1);
  e.box(2,3,1,0,1.5,-5,0x333333,e.scene,true);e.elapsed=1.6;e.fire();assert.equal(e.stats.shots,3);assert.equal(e.stats.hits,2,'opaque cover must stop the bullet');assert.equal(e.ammo,22);
});

test('movement is normalized diagonally, stable across frame rates and stops promptly',()=>{
  const make=keys=>{const e=Object.create(AimRange.prototype);Object.assign(e,{keys:new Set(keys),velocity:new THREE.Vector3(),camera:new THREE.PerspectiveCamera(verticalFov(103),16/9,.025,100),height:1.65,jumpY:0,jumpVel:0,yaw:0,pitch:0,time:0,stepDistance:0,colliders:[],ads:false,audio:{step(){}},weapon:WEAPONS.vandal});return e;};
  const a=make(['KeyW']),b=make(['KeyW']),diagonal=make(['KeyW','KeyD']);for(let i=0;i<120;i++){a.physics(1/120);diagonal.physics(1/120);}for(let i=0;i<60;i++)b.physics(1/60);assert.ok(Math.abs(a.camera.position.z-b.camera.position.z)<.05);near(Math.hypot(diagonal.velocity.x,diagonal.velocity.z),a.velocity.length(),.0001);a.keys.clear();for(let i=0;i<60;i++)a.physics(1/120);assert.ok(a.velocity.length()<.02,'stopping should remove drift');
});

test('Vandal preserves native skinned meshes, UVs, a weighted magazine and synchronized gun clips',async()=>{
 const gun=await cloneNativeAsset('vandal');assert.equal(gun.root.userData.importedAsset,true);assert.deepEqual(gun.clips.map(c=>c.name),['Equip','Fire','Reload']);
 const meshes=[];gun.root.traverse(o=>{if(o.isSkinnedMesh)meshes.push(o);});assert.equal(meshes.length,2);assert.ok(meshes.every(m=>m.geometry.attributes.uv&&m.geometry.attributes.skinWeight));assert.ok(meshes.some(m=>m.name.includes('Magazine')));
 const hands=await cloneNativeAsset('hands');for(const name of ['Equip','Fire','Reload'])near(gun.clips.find(c=>c.name===name).duration,hands.clips.find(c=>c.name===name).duration);
});

test('spray protects six bullets, limits lateral reversal timing and recovers after release',()=>{
 const r=new RecoilController('vandal',()=>0),step=60/585;for(let i=0;i<6;i++){r.shot(i*step);r.update(step,i*step);near(r.targetYaw,0);}r.shot(6*step);const direction=r.direction;assert.notEqual(r.targetYaw,0);for(let i=7;i<12;i++){r.shot(i*step);assert.equal(r.direction,direction);}r.shot(12*step);assert.equal(r.direction,-direction);for(let i=0;i<240;i++)r.update(1/240,12*step+(i+1)/240);assert.equal(r.burst,0);assert.ok(Math.abs(r.pitch)<1e-6);assert.ok(Math.abs(r.yaw)<1e-6);assert.equal(r.shot(3).bullet,1);
});
test('ADS/crouch reduce dispersion and movement/airborne increase angular error',()=>{
 const shot=opts=>new RecoilController('vandal',()=>.25).shot(1,opts),a=shot({});assert.ok(shot({ads:true}).spread<a.spread);assert.ok(shot({crouch:true}).spread<a.spread);assert.ok(shot({speed:5.4}).spread>a.spread*10);assert.ok(shot({airborne:true}).spread>shot({speed:5.4}).spread);near(Math.hypot(a.x,a.y),a.spread*Math.PI/180*.5);assert.deepEqual(shot({enabled:false}),{x:0,y:0,spread:0,bullet:1});
});
test('recoil recovers independently of mouse aim at different frame rates',()=>{
 const simulate=hz=>{const r=new RecoilController('vandal',()=>.4);r.shot(0);for(let i=1;i<=hz;i++)r.update(1/hz,i/hz);return r;};assert.ok(Math.abs(simulate(60).pitch-simulate(240).pitch)<1e-7);const e=Object.create(AimRange.prototype);Object.assign(e,{camera:new THREE.PerspectiveCamera(),settings:{recoil:true},pitch:.12,yaw:.3,spray:{pitch:.06,yaw:-.02}});e.updateCameraAim();near(e.camera.rotation.x,.18);near(e.camera.rotation.y,.28);near(e.pitch,.12);near(e.yaw,.3);
});
test('Gaia overlaps complete clips without stopping prior sounds and cancels pending audio on disposal',async()=>{
 const played=[],stopped=[],ctx={currentTime:1,destination:{},createBufferSource(){return{buffer:null,connect(){return this;},disconnect(){},start(){played.push(this.buffer);},stop(){stopped.push(this.buffer);}};},createGain(){return{gain:{value:0,cancelScheduledValues(){},setTargetAtTime(){}},connect(){return this;},disconnect(){}};},close(){return Promise.resolve();}};
 const a=new RangeAudio({sound:true,volume:.5});a.ctx=ctx;a.killBuffers=['one','two','three','four','five'];for(let i=1;i<=5;i++)a.kill(i);a.kill(6);a.kill(12);assert.deepEqual(played,['one','two','three','four','five','five','five']);assert.equal(stopped.length,0,'a new elimination must never stop a previous clip');assert.equal(a.activeKills.size,7);a.killBuffers=[];let ready;a.loadingKills=new Promise(resolve=>{ready=resolve;});a.kill(2);a.dispose();ready();await Promise.resolve();assert.equal(played.length,7);
});
test('native Jett layers original walking clips and keeps independent skeletons and hitboxes',async()=>{
 const a=await createJett('body'),b=await createJett('body');assert.equal(Object.keys(a.rig.bones).length,121);assert.equal(a.root.userData.originalClips,5);
 const original=b.rig.bones.L_Hip.quaternion.clone();a.rig.updateOpponent(0,true,0,2);a.rig.updateOpponent(.12,true,0,2);assert.ok(a.rig.bones.L_Hip.quaternion.angleTo(original)>.01);assert.ok(b.rig.bones.L_Hip.quaternion.angleTo(original)<1e-6);
 const e=Object.create(AimRange.prototype);Object.assign(e,{scene:new THREE.Scene(),settings:{...DEFAULT_SETTINGS},options:{},p:{accent:0xdf7d51},time:1,disposed:false});const t=e.jettBot();await t.ready;e.poseJett(t,true);e.scene.updateMatrixWorld(true);const head=t.head.getWorldPosition(new THREE.Vector3());const ray=new THREE.Raycaster(head.clone().add(new THREE.Vector3(0,0,3)),new THREE.Vector3(0,0,-1));assert.equal(ray.intersectObjects(t.hitMeshes,false)[0].object.userData.part,'head');assert.ok(t.bindings.every(b=>Number.isFinite(b.mesh.scale.y)&&b.mesh.scale.y>0));assert.ok(head.y>1.5&&head.y<1.8);e.disposed=true;
});
test('dedicated first-person hands retain native clips, grip alignment and a moving reload magazine',async()=>{
 const view=new THREE.Group(),gun=new THREE.Group(),rig=new FirstPersonRig(view,gun);await rig.ready;assert.equal(Object.keys(rig.model.bones).length,112);assert.deepEqual(rig.model.clips.map(c=>c.name),['Idle','Equip','Fire','Reload','Inspect']);
 const wrist=()=>gun.worldToLocal(rig.model.bones.R_Hand.getWorldPosition(new THREE.Vector3()));rig.play('Idle');rig.update({dt:0});const idleWrist=wrist();assert.ok(idleWrist.distanceTo(new THREE.Vector3(-.048,-.054,.039))<.02,'native right wrist must meet the original Vandal grip');
 const magazine=rig.weapon.bones.Magazine_Main;rig.native.updateWorldMatrix(true,true);const before=magazine.getWorldPosition(new THREE.Vector3());
 for(const name of ['Equip','Fire','Reload','Inspect']){rig.play(name,name==='Reload'?2.5:null);for(let i=0;i<12;i++){rig.update({dt:rig.duration/20,time:i/20});view.updateMatrixWorld(true);rig.model.root.traverse(o=>{if(o.isBone)assert.ok(o.matrixWorld.elements.every(Number.isFinite));});}assert.ok(Number.isFinite(wrist().length()));}
 rig.play('Reload',2.5);rig.update({dt:.24});rig.update({dt:.24});rig.native.updateWorldMatrix(true,true);assert.ok(magazine.getWorldPosition(new THREE.Vector3()).distanceTo(before)>.03,'native magazine must move during reload');
 rig.play('Idle');rig.update({dt:0,ads:true});assert.ok(wrist().distanceTo(idleWrist)<.0001,'ADS must translate gun and both hands together');rig.dispose();
});
test('ace continues on every later kill, refreshes five seconds and resets precisely at the deadline',()=>{
 const seq=new KillSequence();for(const time of [0,1,2,3])seq.register(time);assert.deepEqual(seq.register(4),{count:5,clip:5,ace:true});assert.deepEqual(seq.register(8.999),{count:6,clip:5,ace:true});assert.deepEqual(seq.register(13.998),{count:7,clip:5,ace:true});assert.deepEqual(seq.register(18.998),{count:1,clip:1,ace:false});
 // A new session starts at one; pre-ace accumulation does not expire.
 seq.reset();assert.equal(seq.register(100).clip,1);assert.equal(seq.register(120).clip,2);
});

test('rapid fire keeps the gun visible in front of the camera and both wrists on their grips',async()=>{
 const view=new THREE.Group(),gun=new THREE.Group(),rig=new FirstPersonRig(view,gun);await rig.ready;rig.play('Idle');rig.update({dt:0});view.updateMatrixWorld(true);
 const base=gun.getWorldPosition(new THREE.Vector3()),grips={};for(const side of ['L','R'])grips[side]=gun.worldToLocal(rig.model.bones[`${side}_Hand`].getWorldPosition(new THREE.Vector3()));
 const camera=new THREE.PerspectiveCamera(verticalFov(103),16/9,.015,8);camera.updateMatrixWorld();
 for(let frame=0;frame<360;frame++){
  if(frame%12===0)rig.fire();rig.update({dt:1/120});view.updateMatrixWorld(true);
  const pos=gun.getWorldPosition(new THREE.Vector3());assert.ok(pos.distanceTo(base)<.025,'firing offsets must stay near the authored gripping pose');
  const muzzle=gun.localToWorld(new THREE.Vector3(.88214,.08914,0)),ndc=muzzle.clone().project(camera);assert.ok(muzzle.z<-.1&&Math.abs(ndc.x)<1&&Math.abs(ndc.y)<1&&ndc.z<1,'the gun muzzle must stay in the visible camera frustum throughout a spray');
  for(const side of ['L','R'])assert.ok(gun.worldToLocal(rig.model.bones[`${side}_Hand`].getWorldPosition(new THREE.Vector3())).distanceTo(grips[side])<.025,'native grip must not separate during recoil');
 }
 for(let i=0;i<60;i++)rig.update({dt:1/120});near(gun.getWorldPosition(new THREE.Vector3()).distanceTo(base),0,.00001);rig.dispose();
});
test('body animation preserves the original Jett facial proportions and expressions',async()=>{
 const raw=await cloneNativeAsset('body'),jett=await createJett('body');
 const names=['L_EyeLids','R_EyeLids','L_Eyeball','R_Eyeball','L_Brows','R_Brows','Jaw','Mouth_Top','Mouth_Bot'];
 for(let i=0;i<40;i++){
  jett.rig.updateOpponent(i*.1,i>5,0,2,i<20?1:-1);
  for(const name of names){const expected=raw.bones[name],actual=jett.rig.bones[name];near(actual.position.distanceTo(expected.position),0,.000001);near(actual.quaternion.angleTo(expected.quaternion),0,.000001);near(actual.scale.distanceTo(expected.scale),0,.000001);}
 }
});
test('kills queued during audio decoding all play and remain overlapped',async()=>{
 let resolve;const played=[],stopped=[],a=new RangeAudio({sound:true,volume:.5});
 a.ctx={destination:{},createBufferSource(){return{connect(){return this;},disconnect(){},start(){played.push(this.buffer);},stop(){stopped.push(this.buffer);}};},createGain(){return{gain:{value:0},connect(){return this;},disconnect(){}};},close(){return Promise.resolve();}};
 a.loadingKills=new Promise(r=>{resolve=r;});a.kill(1);a.kill(5);a.kill(6);a.killBuffers=['one','two','three','four','ace'];resolve();await Promise.resolve();assert.deepEqual(played,['one','ace','ace']);assert.equal(stopped.length,0);assert.equal(a.activeKills.size,3);
 const first=[...a.activeKills][0];first.source.onended();assert.equal(a.activeKills.size,2);a.dispose();assert.equal(stopped.length,2);
});
test('equip triggers animation and sound once on entry, again on request, and waits for assets',()=>{
 let animations=0,sounds=0;const e=Object.create(AimRange.prototype);Object.assign(e,{preview:false,running:true,equipped:false,reloadTime:0,viewRig:{model:null,play(name){assert.equal(name,'Equip');animations++;}},audio:{equip(){sounds++;}}});
 e.equipWeapon();assert.equal(sounds,0);e.viewRig.model={};e.equipWeapon();e.equipWeapon();assert.equal(sounds,1);assert.equal(animations,1);e.equipWeapon(true);assert.equal(sounds,2);e.reloadTime=1;e.equipWeapon(true);assert.equal(sounds,2);e.reloadTime=0;e.running=false;e.equipWeapon(true);assert.equal(sounds,2);
});

function shootingRange(mode){
 const e=Object.create(AimRange.prototype);Object.assign(e,{p:{accent:0xdf7d51},scene:new THREE.Scene(),renderer:{compatibility:false},colliders:[],occluders:[],running:true,locked:true,countdown:0,ended:false,disposed:false,reloadTime:0,mode,drillRule:DRILL_RULES[mode]||{},goal:DRILL_RULES[mode]?.goal||0,burstGate:mode==='burst'?new BurstGate():null,pairFirstKill:null,weapon:WEAPONS.vandal,weaponKey:'vandal',elapsed:1,shotTime:-10,options:{infinite:false,headOnly:false},ammo:25,settings:{...DEFAULT_SETTINGS,recoil:false},stats:{shots:0,hits:0,headshots:0,kills:0,headKills:0,killIntervals:[],shotPoints:[],transferIntervals:[]},lastKill:0,streak:0,recoil:0,speed:0,jumpY:0,time:1,difficultyScale:1,ray:new THREE.Raycaster(),flash:new THREE.Object3D(),flashLight:{intensity:0},audio:{shot(){},hit(){},kill(){}},tracer(){},impact(){}});
 e.camera=new THREE.PerspectiveCamera(verticalFov(103),16/9,.025,100);e.camera.position.set(0,1.65,0);e.scene.add(e.camera);e.targets=[];return e;
}
test('previous aces continue at a quiet shared background level while the new clip stays in front',()=>{
 const gains=[],stops=[],ctx={currentTime:3,destination:{},createBufferSource(){return{connect(){return this;},disconnect(){},start(){},stop(){stops.push(true);}};},createGain(){const param={value:0,targets:[],cancelScheduledValues(){},setTargetAtTime(value,time,smoothing){this.targets.push({value,time,smoothing});}};gains.push(param);return{gain:param,connect(){return this;},disconnect(){}};},close(){return Promise.resolve();}};
 const a=new RangeAudio({sound:true,volume:.5});a.ctx=ctx;a.killBuffers=['1','2','3','4','ace'];a.kill(5);near(gains[0].value,.325);a.kill(6);near(gains[0].targets.at(-1).value,.325*.18);a.kill(7);near(gains[0].targets.at(-1).value+gains[1].targets.at(-1).value,.325*.18);near(gains[2].value,.325);assert.equal(stops.length,0);a.dispose();
});
test('burst training blocks the fourth bullet and waits 350 ms without consuming ammo',()=>{
 const e=shootingRange('burst');for(const t of [1,1.11,1.22,1.33]){e.elapsed=t;e.fire();}assert.equal(e.stats.shots,3);assert.equal(e.ammo,22);assert.match(e.snapshot().hint,/PAUSA/);e.elapsed=1.58;e.fire();assert.equal(e.stats.shots,4);assert.equal(e.burstGate.bursts,2);assert.equal(e.ammo,21);
});
test('the 30-target challenge ends on kill 30 and cannot record further shots',async()=>{
 const e=shootingRange('range30'),t=e.bot();e.options.infinite=true;e.targets=[t];await t.ready;t.root.position.set(0,0,-10);e.poseJett(t);const head=t.head.getWorldPosition(new THREE.Vector3());e.camera.position.set(head.x,head.y,0);let finishes=0;e.finish=completed=>{assert.equal(completed,true);finishes++;e.ended=true;};
 for(let i=0;i<30;i++){t.alive=true;t.root.visible=true;t.health=150;e.elapsed=1+i*.4;e.fire();if(i<29)assert.equal(finishes,0);}assert.equal(finishes,1);assert.equal(e.stats.kills,30);assert.equal(e.snapshot().goal,30);e.elapsed+=1;e.fire();assert.equal(e.stats.shots,30);
});
test('transfer training waits for the second kill before respawning a coherent new pair',async()=>{
 const e=shootingRange('transfer');e.targets=[e.bot(),e.bot()];await Promise.all(e.targets.map(t=>t.ready));
 for(let i=0;i<2;i++){const t=e.targets[i];t.root.position.set(i===0?-1.1:1.1,0,-12);t.health=150;e.poseJett(t);}e.scene.updateMatrixWorld(true);
 for(let i=0;i<2;i++){const head=e.targets[i].head.getWorldPosition(new THREE.Vector3());e.camera.position.set(head.x,head.y,0);e.elapsed=1+i*.2;e.fire();if(i===0)assert.equal(e.targets[0].respawnAt,Infinity);}
 assert.equal(e.stats.kills,2);near(e.stats.transferIntervals[0],.2);assert.ok(e.targets.every(t=>t.respawnAt===1.6));e.elapsed=1.7;e.updateTargets(.1);assert.ok(e.targets.every(t=>t.alive&&t.health===150));near(e.targets[1].root.position.x-e.targets[0].root.position.x,2.2);near(e.targets[1].root.position.z,e.targets[0].root.position.z);
});
test('equip/inspect transitions are continuous and externally timed reloads return to idle once',async()=>{
 const view=new THREE.Group(),gun=new THREE.Group(),rig=new FirstPersonRig(view,gun);await rig.ready;rig.update({dt:0});const idle=gun.getWorldPosition(new THREE.Vector3());rig.inspect();rig.update({dt:0});near(gun.getWorldPosition(new THREE.Vector3()).distanceTo(idle),0,.00001);
 for(let i=0;i<30;i++)rig.update({dt:1/120});const posed=gun.getWorldPosition(new THREE.Vector3());rig.play('Idle');rig.update({dt:0});near(gun.getWorldPosition(new THREE.Vector3()).distanceTo(posed),0,.00001);rig.update({dt:.15});near(gun.getWorldPosition(new THREE.Vector3()).distanceTo(idle),0,.00001);
 rig.reload(2.5);rig.update({dt:.12,reloadProgress:.2});rig.update({dt:.12,reloadProgress:.95});near(rig.handActions.Reload.time,rig.handActions.Reload.getClip().duration*.95,.00001);rig.update({dt:.5,reloadProgress:1});assert.equal(rig.state,'Reload');rig.update({dt:.12,reloadProgress:null});assert.equal(rig.state,'Idle');rig.update({dt:.3});assert.equal(rig.state,'Idle');rig.dispose();
});
test('default crosshair is a three-pixel dot and custom crosshair format remains valid',()=>{
 assert.equal(DEFAULT_SETTINGS.crosshairStyle,'dot');assert.equal(DEFAULT_SETTINGS.size,3);assert.equal(validateSettings({...DEFAULT_SETTINGS,crosshairStyle:'cross'}).crosshairStyle,'cross');assert.equal(validateSettings({...DEFAULT_SETTINGS,crosshairStyle:'bad'}).crosshairStyle,'dot');
});

test('reload animation and reload lock use the same active time even on slow frames',()=>{
 const e=shootingRange('micro'),original=globalThis.requestAnimationFrame;let animationDelta=0;globalThis.requestAnimationFrame=()=>1;
 Object.assign(e,{lastFrame:1000,time:0,frameAvg:16.67,uiTime:0,effects:[],reloadTime:1.2,held:false,viewRig:{state:'Reload',update({dt}){animationDelta=dt;}},spray:{update(){},yaw:0,pitch:0},updateTargets(){},physics(){},renderer:{compatibility:true,render(){},clearDepth(){}}});
 try{e.frame(1600);near(e.reloadTime,.6);near(animationDelta,.6);}finally{if(original)globalThis.requestAnimationFrame=original;else delete globalThis.requestAnimationFrame;}
});
