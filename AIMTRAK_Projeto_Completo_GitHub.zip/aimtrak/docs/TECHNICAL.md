# AIMTRAK

Independent browser aim trainer focused on Valorant practice. Static, local assets,
eleven drills, routines, history, sensitivity configuration and a portable HTML build.
This is not an official Valorant client or a validated replacement for other trainers.

## v0.4.0

Default crosshair is a three-pixel dot, with a cross option retained in settings.
Existing profiles migrate to the requested dot once. Weapon actions crossfade over
90 ms; reload animation follows the actual reload progress, including slower frames.
Opponent direction changes blend between the native east/west walking clips.
Cancelling the drill selector resumes the live preview instead of freezing it.

The player uses the dedicated first-person Jett mesh (112 bones), with original
Vandal hand clips for equip, fire, reload and inspect. The actual native Vandal mesh
includes a separately skinned magazine and synchronized gun animation clips. The
weapon follows the original MasterWeapon socket. Fire uses an additive weapon/trigger
layer over the original gripping pose, so it cannot replace the arm rig with offsets
at the world origin. Generic body clips do not animate Jett-specific facial bones;
the original eyes, brows, mouth and hair retain their authored local transforms. Legacy import bone-axis metadata
is retained, so fingers and wrists are not reconstructed with procedural IK.

Opponents use a native 121-bone Jett model, with original upper-body rifle grip and
lower-body idle/lateral walking clips. Head and limb hit proxies follow the animated
skeleton. Meshes, skin weights, UVs, diffuse/normal maps and original clips come from
the public Rocklan model pack; see dist/licenses/native-assets.txt and the source/hash
manifest in scripts/native-clips-manifest.json. The original first-person eye origin
is 1.673455 m. Assets are resampled at 30 Hz, with continuous interpolation at runtime.

The new practice court has solid plaster walls, timber columns, terracotta roofs,
clear firing lanes and physical cover, with day/night palettes. The viewmodel renders
in a separate depth pass to prevent distortion or clipping against the arena.

The user's five Gaia MP3 kill sounds remain unchanged. Every kill plays its full
clip. A new clip reduces the previous clips to a shared quiet background budget
(18% of the newest clip), keeping the newest at 65% of the configured volume.
No clip is truncated; playback is only stopped when leaving the session. Pending decoding does not discard earlier kills. A
synthesized equip sound accompanies the native Equip animation on entry and on key 1. Kills 1–5 advance the audio;
after ace, every further kill plays clip 5 and refreshes its five-second window.
Five seconds without a kill after ace resets the next kill to clip 1. Session time
stops while paused. Each new session resets the sequence. The native Gaia
skin is not installed. The actual ILilMitch model was located, but its official
download requires authentication; alternative public hosts blocked downloads.
See docs/gaia-research.json. A GLB/glTF ZIP from the official download is needed.
The earlier procedural reconstruction has not been reintroduced.

## Run and controls

Serve dist/ with HTTP/HTTPS; the module entry does not support file://. No build step
or external runtime CDN is needed. Normal rendering uses Three.js WebGL 2 and pointer
lock with unadjustedMovement when supported. The explicitly labeled CPU renderer and
right-drag exploration mode are fallbacks; the latter cannot validate raw mouse input.
The current cloud QA browser disables WebGL and pointer capture.

WASD move, Shift walk, Ctrl/C crouch, Space jump, mouse 1 shoot, mouse 2 ADS,
1 equip, R reload, V inspect, Esc pause; compatibility exploration uses right-drag and Z ADS.
Training currently exposes the native Vandal. Weapon profiles for other guns remain
in the simulation code but their provisional drawn models are no longer offered.

## Sensitivity and training

Default sensitivity: 0.175; DPI: 1600; eDPI: 280; cm/360: 46.653061. Existing profiles
on the former 0.165 default migrate once; custom sensitivity values are preserved.

rotationRadians = movementCounts × sensitivity × 0.07 × π / 180 × calibrationFactor

DPI is used for physical-distance reporting, never multiplied into mouse deltas again.
World camera FOV is 103° horizontal at 16:9. The browser cannot detect or change DPI.
Hardware/OS/browser handling can affect physical equivalence; check the included
measured 360° calibration. Recoil, spread, movement and ADS remain approximations.

Recoil separates camera offsets from mouse aim. The Vandal training profile uses six
protected bullets, 0.6 s lateral reversal timing, 10% reversal probability and 0.375 s
recovery based on public Riot patch notes. The vertical curve is an approximation.
References: https://playvalorant.com/en-us/news/game-updates/valorant-patch-notes-11-08/
and https://playvalorant.com/en-us/news/game-updates/valorant-patch-notes-0-50/

Eleven drills include microadjustments, flicks, strafing, cover peeks, tracking,
long-range precision, reaction, free practice and these new Valorant-focused drills:
- Desafio 30: one 150-HP Jett at a time, headshots, elapsed time, ends on kill 30.
- Rajadas de 3 tiros: up to three shots, then a 350-ms recovery pause; 150-HP targets.
- Transferência de spray: paired 150-HP targets, next pair only after both kills;
  transfer timing measures the gap between the first and second elimination. A routine, results, shot plots and
JSON export use actual session data. Profile and the latest 100 sessions persist
in localStorage, per browser/origin, without cross-device sync.

## Prepare, verify and package

Run node --test tests/training.test.mjs for sensitivity, FOV, input validation,
head/body/cover hits, ammo, cadence, movement, recoil, audio sequencing, native
skeleton independence, hand/gun synchronization, grip alignment and magazine motion.

Download the public blend files linked in dist/licenses/native-assets.txt, then use
scripts/recover-native-clips.py for the PSA files. Conversion uses official Blender
4.5 and DarklightGames io_scene_psk_psa 7.1.0 as a build dependency. Run Blender with
--background --disable-autoexec --python scripts/prepare-native-assets.py -- INPUT
ADDON_DIRECTORY OUTPUT; then run node scripts/embed-native-assets.mjs OUTPUT. No source-embedded Blender scripts are executed.

node scripts/build-portable.mjs /absolute/output/AIMTRAK.html

The portable HTML embeds scripts, fonts, textures, meshes, animation clips and audio,
without external runtime dependencies or a Sites sign-in. It retains the same
training limitations. Standard module hosting and the portable document share code.
