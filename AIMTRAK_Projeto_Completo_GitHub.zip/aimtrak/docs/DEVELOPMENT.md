# Desenvolvimento e publicação

## Requisitos

Node.js 22 ou superior e npm. O jogo em si é estático e já inclui seus recursos;
Node e as dependências npm são usados para o servidor, os testes e o empacotamento.
Não há backend, banco de dados, chaves privadas ou arquivo `.env` obrigatório.

```sh
npm ci
npm run dev
```

O servidor escuta somente no computador local, na porta 4173. Para mudar a porta:

```sh
# PowerShell
$env:AIMTRAK_PORT=8080
npm run dev
```

```sh
# Linux / macOS
AIMTRAK_PORT=8080 npm run dev
```

## Validação

```sh
npm run check
npm test
npm run build
```

A pasta `build/` é gerada e não precisa ser commitada. Ela contém `index.html`, os
módulos e arquivos de `dist/`, além do portátil `AIMTRAK.html`. Para hospedar em
outro serviço estático, publique o conteúdo de `build/` na raiz desse serviço.
Os caminhos do jogo são relativos e suportam a subpasta de um projeto no Pages.

`AIMTRAK.html` na raiz é uma distribuição commitada para download direto; ao
alterar código em `dist/`, execute `npm run build:portable` antes do commit para
atualizá-la. A integração contínua também gera e guarda esse HTML como artefato.

## GitHub Pages

O workflow `pages.yml` roda em pushes para `main` e manualmente. Antes da primeira
publicação, o administrador do repositório deve selecionar **Settings → Pages →
Source → GitHub Actions**. Se o repositório for privado, a disponibilidade do Pages
também depende do plano e das políticas da conta.

Depois de habilitar Pages, execute **Actions → Publicar GitHub Pages → Run workflow**.
O workflow usa os recursos oficiais de Pages: configuração, upload do artefato e
deploy pelo ambiente `github-pages`. O endereço efetivamente publicado aparece
nesse ambiente e no resumo da execução; confirme o sucesso antes de divulgar o link.

A CI de `ci.yml` roda separadamente em pushes e pull requests para `main`. Ela
verifica a sintaxe, executa os testes, gera o build e disponibiliza o portátil como
artefato, mesmo sem Pages habilitado.

## Modelos, sons e manutenção

- `dist/assets/native-data.js`: dados embutidos de modelos, texturas e animações.
- `dist/assets/gaia-audio-data.js`: os cinco sons fornecidos para o projeto.
- `scripts/native-clips-manifest.json`: fontes e hashes dos clipes usados.
- `scripts/prepare-native-assets.py` e `scripts/embed-native-assets.mjs`: conversão
  dos recursos originais. Blender não é necessário para jogar ou para o build HTML.
- `dist/licenses/`: créditos, fontes e avisos dos recursos de terceiros.

A Gaia visual segue pendente de um GLB/glTF autorizado para download. Não substitua
o modelo por uma reconstrução improvisada sem registrar claramente a mudança.
Mantenha os avisos dos autores ao redistribuir os recursos.

## Dados do jogador

Perfil e histórico ficam em `localStorage`, por navegador e origem. Mudar do site
atual para Pages cria um espaço de armazenamento diferente. Exporte seus resultados
antes de trocar de endereço se quiser preservar uma cópia; não há sincronização
automática entre hospedagens.
